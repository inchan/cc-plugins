---
description: TODO: Brief description of what this command does
---

# Command: /TODO

TODO: Add your command instructions here.

## Purpose

TODO: Explain what this command does and when to use it.

## Steps

1. TODO: First step
2. TODO: Second step
3. TODO: Third step

## Guidelines

- TODO: Important guideline
- TODO: Another guideline

## Expected Output

TODO: Describe what the command should produce.
