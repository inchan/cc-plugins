---
description: TODO: What specialized analysis this provides
allowed-tools: Task
argument-hint: [TODO: target]
---

# TODO: Specialized Analysis: $ARGUMENTS

Launch specialized subagent for expert analysis.

## Subagent Configuration

Use the Task tool to launch **TODO: subagent-name** subagent.

## Context to Provide

**Target:** $ARGUMENTS

**Scope:**
- TODO: What to analyze
- TODO: What to focus on
- TODO: What to check

**Requirements:**
- TODO: What the agent should do
- TODO: What analysis to perform
- TODO: What patterns to look for

## Deliverables Expected

The subagent should provide:

1. **TODO: Primary deliverable**
   - Format: TODO: How it should be formatted
   - Content: TODO: What it should include

2. **TODO: Secondary deliverable**
   - Format: TODO: How it should be formatted
   - Content: TODO: What it should include

3. **TODO: Additional deliverable**
   - Format: TODO: How it should be formatted
   - Content: TODO: What it should include

## Success Criteria

- [ ] Subagent completed analysis
- [ ] All deliverables provided
- [ ] Findings are specific and actionable
- [ ] Recommendations are prioritized
- [ ] Examples provided where helpful

## Next Steps

Based on subagent findings, consider:
- TODO: Possible next action
- TODO: Another possible action
- TODO: Follow-up command to run
