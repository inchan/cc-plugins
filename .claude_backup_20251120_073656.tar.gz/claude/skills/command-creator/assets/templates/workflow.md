---
description: TODO: Multi-step workflow description
allowed-tools: Read, Write, Edit, Bash, Grep, Glob, TodoWrite
argument-hint: [TODO: arguments]
---

# TODO: Workflow Name: $ARGUMENTS

Execute a comprehensive workflow with multiple phases.

## Phase 1: TODO: Phase Name

**Objective:** TODO: What this phase accomplishes

**Steps:**
1. TODO: First step
2. TODO: Second step
3. TODO: Third step

**Output:** TODO: What this phase produces

## Phase 2: TODO: Phase Name

**Objective:** TODO: What this phase accomplishes

**Steps:**
1. TODO: First step
2. TODO: Second step
3. TODO: Third step

**Output:** TODO: What this phase produces

## Phase 3: TODO: Phase Name

**Objective:** TODO: What this phase accomplishes

**Steps:**
1. TODO: First step
2. TODO: Second step
3. TODO: Third step

**Output:** TODO: What this phase produces

## Summary

Provide a comprehensive report including:
1. Summary of all phases
2. Key findings or results
3. Any issues encountered
4. Next recommended actions

## Success Criteria

- [ ] All phases completed successfully
- [ ] Clear documentation of results
- [ ] No errors or warnings
- [ ] Ready for next step in process
