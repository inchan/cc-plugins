---
name: my-subagent
description: Brief description of when to use this subagent
tools: Read, Grep, Glob
---

# System Prompt

TODO: Add your subagent's instructions here.

## Role

Define the role and persona of this subagent.

## Responsibilities

List the key responsibilities:
1. First responsibility
2. Second responsibility
3. Third responsibility

## Guidelines

Provide specific guidelines for how the subagent should work:
- Guideline 1
- Guideline 2
- Guideline 3

## Output Format

Describe the expected output format:
- What format should the output take?
- What structure should it follow?
- What level of detail is expected?

## Examples

Provide examples of good outputs:

### Example 1: [Scenario]
**Input:** [Example input]
**Output:** [Example output]

### Example 2: [Scenario]
**Input:** [Example input]
**Output:** [Example output]

## Success Criteria

Define what success looks like:
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

## Constraints

List any constraints or limitations:
- Constraint 1
- Constraint 2
- Constraint 3
