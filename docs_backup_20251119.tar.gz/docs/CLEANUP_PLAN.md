# docs 폴더 정리 계획

**작성일**: 2025-11-19
**작성자**: Claude Code

## 🎯 목표
- 중복 문서 제거
- 불필요한 문서 삭제
- 구조 단순화
- 유지보수성 향상

## 📊 현황 분석

### 폴더별 파일 수 및 크기
| 폴더 | 파일 수 | 총 크기 | 상태 |
|------|---------|---------|------|
| agent-patterns | 4개 | 66KB | 부분 중복 |
| plan | 4개 | 43KB | 대부분 불필요 |
| reports | 9개 | 178KB | 대부분 불필요 |
| review | 21개 | 35KB | 통합 필요 |
| skills-guide | 6개 | 67KB | 부분 중복 |

**총계**: 44개 파일, 약 389KB

---

## 🗑️ 삭제 대상 (불필요/오래된 문서)

### 1. reports 폴더 (대부분 삭제)
| 파일명 | 크기 | 이유 |
|--------|------|------|
| ACTUAL_SKILL_TESTS.md | 46KB | 테스트 실행 로그, 히스토리로만 가치 |
| SKILL_COMPLIANCE_REPORT.md | 8KB | 이미 해결된 디렉토리 구조 문제 |
| OFFICIAL_STANDARDS_COMPLIANCE.md | 8.6KB | SKILL_COMPLIANCE_REPORT와 중복 |
| FLOW_VALIDATION_REPORT.md | 27KB | 구현 완료된 플로우 검증 |
| INTEGRATION_VALIDATION_REPORT.md | 22KB | 구현 완료된 통합 검증 |
| VALIDATION_SUMMARY.md | 12KB | 다른 검증 보고서와 중복 |
| SKILL_REVIEW_REPORTS.md | 34KB | 개별 리뷰 파일들과 중복 |
| ANALYSIS_REPORT.md | 22KB | 구현 완료된 분석 |
| ADVISOR_ITERATION_LOG.md | 9.4KB | advisor 스킬의 개발 로그 |

**삭제 예정**: reports 폴더 전체 (178KB)

### 2. plan 폴더 (구현 완료된 계획)
| 파일명 | 크기 | 이유 |
|--------|------|------|
| parallel-task-executor.md | 19KB | 이미 구현 완료 |
| cli-adapter-resolution-strategy.md | 9KB | 이미 해결 완료 |
| cli-improvements-summary.md | 6.1KB | 이미 구현 완료 |
| dual-ai-loop-review.md | 9.5KB | 이미 구현 완료 |

**삭제 예정**: plan 폴더 전체 (43KB)

### 3. agent-patterns 폴더 (부분 삭제)
| 파일명 | 크기 | 이유 |
|--------|------|------|
| AGENT_PATTERNS_FILELIST.md | 17KB | 단순 파일 목록 |

**삭제 예정**: 1개 파일 (17KB)

---

## 📦 통합 대상 (여러 파일을 하나로)

### 1. review 폴더 (21개 파일 → 1개)
현재 각 스킬별로 개별 리뷰 파일이 있음 (각 1-2KB)

**통합 방안**:
- `SKILLS_REVIEW_SUMMARY.md` 하나로 통합
- 각 스킬별 섹션으로 구성
- prompt-enhancer-simplification-report.md는 별도 유지 (최신 작업)
- cli-adapters-self-critique.md 삭제 (구현 완료)

**예상 결과**: 21개 파일 → 2개 파일

---

## ✅ 유지 대상 (중요 문서)

### 반드시 유지
1. **CLAUDE.md** (루트) - 메인 통합 관리 가이드
2. **docs/SKILL-DEVELOPMENT-GUIDE.md** - 스킬 개발 가이드
3. **docs/review/prompt-enhancer-simplification-report.md** - 최신 작업 보고서
4. **agent-patterns/INTER_SKILL_PROTOCOL.md** - 스킬 간 프로토콜
5. **agent-patterns/AGENT_PATTERNS_README.md** - 패턴 설명
6. **skills-guide/README.md** - 스킬 가이드 메인

### 검토 후 유지
- **skills-guide/DECISION_TREE.md** - 의사결정 가이드
- **skills-guide/COMMON_PITFALLS.md** - 주의사항 모음

---

## 📁 최종 구조 (정리 후)

```
docs/
├── SKILL-DEVELOPMENT-GUIDE.md        # 스킬 개발 가이드
├── agent-patterns/
│   ├── AGENT_PATTERNS_README.md      # 패턴 설명
│   ├── INTER_SKILL_PROTOCOL.md       # 프로토콜 정의
│   └── AGENT_PATTERN_IMPROVEMENTS.md # 개선 제안
├── review/
│   ├── SKILLS_REVIEW_SUMMARY.md      # 통합 리뷰 (새로 생성)
│   └── prompt-enhancer-simplification-report.md  # 최신 작업
└── skills-guide/
    ├── README.md                      # 메인 가이드
    ├── DECISION_TREE.md               # 의사결정 트리
    └── COMMON_PITFALLS.md             # 주의사항
```

---

## 🔢 예상 효과

### Before
- 44개 파일, 389KB
- 중복 내용 많음
- 구조 복잡
- 오래된 정보 혼재

### After
- 약 10개 파일, 약 100KB
- 중복 제거
- 명확한 구조
- 최신 정보만 유지

**공간 절약**: 약 **74% 감소** (389KB → 100KB)
**파일 수**: 약 **77% 감소** (44개 → 10개)

---

## 📋 실행 절차

1. **백업 생성** (안전을 위해)
   ```bash
   tar -czf docs_backup_20251119.tar.gz docs/
   ```

2. **불필요 폴더 삭제**
   - reports/ 폴더 전체
   - plan/ 폴더 전체

3. **개별 파일 삭제**
   - agent-patterns/AGENT_PATTERNS_FILELIST.md

4. **review 폴더 통합**
   - 20개 개별 리뷰 → SKILLS_REVIEW_SUMMARY.md
   - cli-adapters-self-critique.md 삭제

5. **skills-guide 폴더 정리**
   - 중복 내용 제거
   - 핵심 3개 파일만 유지

---

## ⚠️ 주의사항

1. **백업 필수**: 삭제 전 반드시 백업 생성
2. **참조 확인**: 다른 파일에서 참조하는 문서는 삭제 주의
3. **히스토리 보존**: 필요시 `docs/archive/` 폴더 생성하여 이동

---

**승인 후 실행 예정**